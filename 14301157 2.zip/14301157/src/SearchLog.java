
public interface SearchLog {

}
