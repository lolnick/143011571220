import java.util.Date;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class WriteDb implements SearchLog {

	@Override
	public boolean write_to_database(String userId, String sContent) {
		// TODO Auto-generated method stub
		Jedis  redis = new Jedis ("192.168.10.64",6379);//连接redis     
        redis.auth("redis");//验证密码
        Format format = new SimpleDateFormat("yyyyMMdd");
     //   System.out.println(format.format(new Date()));
        String date=format.format(new Date());
        Map hmap = new HashMap();   
       // hmap.put("userId", userId);   
        hmap.put("searchContent", sContent);   
        hmap.put("date", date);
        redis.hset(userId, hmap);
		
		return false;
	}

}
